---
name: reviewed-skill
description: Safe cross-client fixture
---
# Reviewed skill
